package MustBe::Loaded;

$VERSION = 0.01;

1;
