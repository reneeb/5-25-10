$VERSION = 1;

package Y;

$VERSION = 2;

package NotX;

$VERSION = 3;

package X;

$VERSION = 4;

1;
