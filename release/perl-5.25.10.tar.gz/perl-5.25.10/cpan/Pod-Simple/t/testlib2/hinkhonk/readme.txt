This directory should never be scanned.
